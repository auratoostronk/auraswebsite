Aura's Instagib Chaos by hiimaura.

Made for Zandronum. May work with other Zdoom ports, but no guarantees.

This mod was developed by hiimaura with a little help from Seidolon. Many resources were used but
not made by the developers, but may have been modified by them. These resources are
creditted in the .pk3 in various credits.txt located alongside these resources. If you'd
like to view the credits, or look inside/modify this .pk3 for any means, the best 
way is to use Slade at slade.mancubus.net. 

To play offline with bots, I recommend using a multiplayer map pack of some sort and
going to Options > Multiplayer Options > Offline Skrimish. Make sure you select the
proper maps and add bots to your game under Bot Setup. Also, I recommend setting a
frag limit, so you don't stay on the same map. Unless you want that. 

For setting up a multiplayer game: It is REQUIRED that you enable "Clients Send Full Button Info"
This may be a checkbox in your server setup, or you may need to use the console command
"set compat_clientssendfullbuttoninfo 1". This enables the "Roll" ability to work.

The mystery box items use the Hexen inventory controls. In the "Customize Controls" menu, 
there is a section called "Inventory". Make sure you bind "Use Item" and "Next Item", and
preferably "Previous Item". This will allow you to cycle through your Mystery Box items,
and use them of course.

That should wrap it up. If you have any questions, leave a comment on the forum page or the
youtube video that linked you to this. I may have forgotten some important information, so
please do let me know ASAP.

Peace!
-hiimaura